<?php
?>
<footer id="footer" class="footer dark-background">
  <div class="container text-center py-3">
    © <?= date('Y') ?> AgriCulture. All Rights Reserved.
  </div>
</footer>

<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<div id="preloader"></div>

<!-- Vendor JS Files (include bootstrap bundle once) -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

<!-- service modal script -->
<script src="assets/js/service-modal.js"></script>

<!-- Main JS File -->
<script src="assets/js/main.js"></script>
</body>
</html>